$(document).ready(function () {
    $('.bxslider').bxSlider({
        pager: false,
        speed: 2000
    });
    $('.slider').bxSlider({
        minSlides: 3,
        maxSlides: 6,
        slideWidth: 101,
        slideMargin: 80,
        pager: false
    });
});


